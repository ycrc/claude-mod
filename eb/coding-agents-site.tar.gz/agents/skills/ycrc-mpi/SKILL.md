---
name: ycrc-mpi
description: Use for MPI and mpi4py on YCRC clusters, including MPI ranks/tasks, multi-node jobs, dedicated MPI partitions, whole-node suitability, hybrid MPI+threads, module/toolchain compatibility, and container MPI.
---

# YCRC MPI workflows

MPI is for communicating parallel processes. Do not infer that a workload needs MPI merely because it uses many CPUs or invokes `mpirun`.

## Decide whether MPI is actually needed

Before designing an MPI job:

- Determine whether the application is genuinely MPI-enabled and whether ranks communicate.
- For independent tasks, prefer `ycrc-dsq-arrays`.
- For one multithreaded process, use `--cpus-per-task` and `ycrc-parallel`.
- YCRC's mpi4py guidance describes MPI as a comparatively advanced/last-resort approach when work cannot be restructured into simpler independent parallelism.

## Slurm mapping

MPI workers/ranks map to Slurm tasks:

- `--ntasks` / `-n` = number of MPI ranks/tasks.
- `--cpus-per-task` = CPUs/threads available to each rank.
- `--nodes` and `--ntasks-per-node` control multi-node placement when needed.

For four single-CPU ranks, the conceptual request is:

```bash
--ntasks=4
--cpus-per-task=1
```

Do not use `-n` as a synonym for total CPUs.

For hybrid MPI + threads, request multiple tasks and multiple CPUs per task, and configure the application's thread count to match. Use `ycrc-parallel` for the general task/thread distinction.

## Dedicated MPI partitions

A dedicated MPI partition is for tightly coupled, multi-node MPI applications that need whole/exclusive nodes or hardware consistency. **Using `mpirun` does not by itself justify a dedicated MPI partition**; MPI jobs that do not require exclusive nodes should use ordinary suitable partitions. This cluster's MPI partitions and hardware:

## On Bouchet

### The dedicated `mpi` partition is special

Bouchet's `mpi` partition allocates **full, identical nodes** and is reserved for tightly coupled MPI-enabled applications that:

- span multiple nodes; and
- need exclusive/whole nodes or are sensitive to node sharing/hardware differences.

Most appropriate jobs use all cores on each allocated node, though YCRC documents limited exceptions for tightly coupled workloads constrained by memory/load-balancing/core-count requirements.

**Using `mpirun` does not by itself justify the `mpi` partition.** MPI jobs that do not require exclusive nodes should use ordinary suitable partitions. Small/single-core jobs submitted to `mpi` may be cancelled without warning.

Bouchet's current YCRC documentation describes the `mpi` nodes as 64-core dual Emerald Rapids Platinum 8562Y+ systems with about 487 GiB usable RAM. Treat hardware as documentation-derived, not live availability; query Slurm for current state.

### `scavenge_mpi`

YCRC also documents `scavenge_mpi` for the same class of MPI workload at lower priority, subject to preemption. Route preemption/checkpoint/requeue decisions through `ycrc-scavenge`; do not assume every MPI application can safely resume after preemption.

### Compiling for the `mpi` nodes

YCRC documents a Bouchet `devel` node matching the MPI generation for optimized compilation, selectable with:

```bash
--partition=devel --constraint=cpugen:emeraldrapids
```

For YCRC-derived detail on Bouchet's MPI partitions, read `references/mpi-ycrc.md`.

## Compilation and modules

- Keep compiler/MPI/application toolchains compatible. Do not mix arbitrary MPI implementations across build and runtime.
- When the cluster has a `devel` node matching its MPI nodes' CPU generation (listed above), compile optimized code there.
- Discover current module versions rather than hard-coding old examples.

## mpi4py

- Python work on YCRC clusters uses Conda (see `ycrc-conda`). Multi-node `mpi4py` is the one exception: YCRC warns that `mpi4py` installed via Conda is unaware of cluster infrastructure and will likely work only on a single compute node.
- For `mpi4py` across nodes, use YCRC's `mpi4py` module, which brings its matching OpenMPI and Python; find the current version with `module avail mpi4py` rather than hard-coding one. For single-node `mpi4py`, Conda is fine.
- If a multi-node job needs Python packages the module doesn't provide, direct the user to YCRC at `research.computing@yale.edu` rather than inventing a workaround.

## Apptainer + MPI

YCRC notes that MPI inside Apptainer requires the MPI version inside the container to be compatible with the cluster MPI. Route container mechanics to `ycrc-apptainer`; do not assume arbitrary container MPI binaries will work across nodes.
