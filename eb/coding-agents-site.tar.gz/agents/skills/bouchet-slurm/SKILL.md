---
name: bouchet-slurm
description: Use for Slurm jobs, sbatch/srun/salloc, resource requests, partitions, CPU/memory/walltime/GPU requests, and durable batch workflows on YCRC Bouchet.
---

# Bouchet Slurm

- Computational work belongs in Slurm jobs/allocations, not on login or transfer nodes.
- The coding agent already runs inside its own small `agent`-partition allocation, meant for coordination, editing, inspection, small tests and job submission. Do not request another `agent` allocation, and do not run substantial computation in the session: submit it with `sbatch` to the appropriate CPU, GPU or development partition.
- For short CPU development and testing, use `devel`; for GPU development, `gpu_devel` (see `bouchet-gpu`). Their per-user limits are aggregate across all of a user's jobs in the partition; check the current values (see `references/slurm-resources.md`) rather than relying on remembered numbers.
- Before suggesting or submitting to `devel` or `gpu_devel`, check the user's current jobs there (`squeue -u $USER -p devel,gpu_devel`; in Open WebUI, `my_jobs`). Open OnDemand sessions (Jupyter, RStudio, VS Code, Open WebUI, Remote Desktop) and `salloc`, whose default partition on Bouchet is `devel`, often already occupy them. `gpu_devel` allows one job per user; `devel` allows 2 jobs and **4 CPUs and 60G in total across all of the user's `devel` jobs**, not per job. Add up the CPUs and memory their `devel` jobs already hold (`squeue -u $USER -p devel -o '%i %C %m %T'`; `my_jobs` in Open WebUI shows the same columns) and size the new request to what is left: with a 2-CPU Jupyter session running, a new `devel` job can have at most 2 CPUs (memory defaults to 5G per CPU). The limits fail differently: a job over the job count is rejected at once (`QOSMaxSubmitJobPerUserLimit`), but a job over the CPU or memory total is accepted and stays pending (`QOSMaxCpuPerUserLimit`, `QOSMaxMemoryPerUser`) until other `devel` jobs end. If the new work would not fit, run CPU work in `day` (or `week`), and for GPU work either end the existing `gpu_devel` job or submit the work as a batch job to a production GPU partition (interactive GPU work has no other partition).
- Interactive jobs (Open OnDemand sessions and `salloc`) also count toward the `interactive` QOS: at most 4 running per user across all partitions. A fifth is accepted but waits (`QOSMaxJobsPerUserLimit`) until one ends; batch jobs are not affected. `squeue -u $USER -o '%i %P %q %j'` shows which of the user's jobs are interactive (QOS column); if they already have 4, suggest ending an idle session or using a batch job.
- Course accounts (username `courseid_netid`) can also use `education` (CPU: per user 4 jobs, 16 CPUs and 200G in total) and `education_gpu` (1 job, 1 GPU per user; RTX 5000 Ada, A5000, A40), each up to 1 day, portal sessions up to 6 hours. Prefer them for course work when they have room and the work fits; otherwise use the public partitions. Check room with `sinfo -p education,education_gpu -o '%P %C %G'`.
- Match CPU, memory, GPU, and walltime requests to the workload.
- Prefer durable `sbatch` scripts for longer-running work.
- `sbatch` and `srun` are intentionally permitted by this deployment. Jobs they launch run as normal user Slurm jobs outside the interactive coding-agent Apptainer filesystem sandbox.
- Do not assume paths visible only inside the interactive container will exist in a submitted job.
- Do not kill or signal another user's jobs or processes.
- Do not assume that the partition literally named `gpu` contains all GPU resources. When asked what GPU partitions or GPU types exist, inspect all partitions/nodes (for example with `sinfo -h -o "%P %G %N"` or `sinfo -N -h -o "%N %P %G"`) rather than restricting discovery with `sinfo -p gpu`.
- A partition may exist without being available to the current user. For `priority_*`, do not merely check entitlement: Priority Tier is paid. Route to `bouchet-priority` and obtain explicit user confirmation before actually submitting, resubmitting, launching an interactive allocation, or moving a job into Priority Tier.
- `admintest` is never an allowed target for this normal-user coding-agent deployment. Do not recommend it and do not submit jobs to it.
- Interactive GPU work on Bouchet must use `gpu_devel`. Do not use Standard Tier production GPU partitions such as `gpu` for interactive allocations, even if changing QOS or another option makes Slurm accept the request. Scheduler acceptance does not override YCRC policy. Priority Tier is a documented paid exception for entitled users; use `bouchet-priority` and obtain confirmation before launching it.
- For shell-style interactive allocations, use either `salloc <resources>` or `srun <resources> --pty bash -i`; do not use `salloc --pty`.

## Route specialized Slurm questions to the focused skills

- For general tasks vs. CPUs, threading, multiprocessing, GNU Parallel, or CPU layout, use `bouchet-parallel`.
- For MPI, mpi4py, MPI ranks, multi-node MPI, the `mpi`/`scavenge_mpi` partitions, or hybrid MPI+threads, use `bouchet-mpi`.
- For pending jobs, failed/cancelled jobs, OOM/timeout diagnosis, resource efficiency, quotas, submission-rate failures, or batch-vs-interactive discrepancies, use `bouchet-job-troubleshooting`.
- For large independent batches and job arrays, use `bouchet-dsq-arrays`.
- For GPU sizing, GPU memory, GPU types, CUDA, Jobstats GPU utilization, and multi-GPU layouts, use `bouchet-gpu`.
- For `priority`, `priority_gpu`, `priority_mpi`, paid Priority Tier credits, `prio_` accounts, or Priority Tier costs/usage, use `bouchet-priority`.
- For `scavenge`, `scavenge_gpu`, preemption, requeue/checkpoint decisions, or opportunistic capacity, use `bouchet-scavenge`.
- For Apptainer/Singularity containers, use `bouchet-apptainer`.
- For AlphaFold workflows, use `bouchet-alphafold`.
- For CryoSPARC workflows, use `bouchet-cryosparc`.

Keep this skill as the general Slurm entry point; do not invent detailed parallel or failure-remediation rules when a focused Bouchet skill applies.

For supporting detail, read `references/slurm-resources.md`.
