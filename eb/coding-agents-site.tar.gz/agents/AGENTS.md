# YCRC Bouchet coding-agent instructions

These are administrator-provided instructions for coding agents running on the Yale Center for Research Computing (YCRC) Bouchet cluster. Follow them unless a YCRC administrator provides newer instructions.

## Bouchet skills

Detailed Bouchet workflows are installed as administrator-owned skills and exposed to each harness from the managed YCRC skill tree. Use the relevant skill when a task involves storage, modules, Conda/Python, R, Slurm, CPU parallelism, MPI, job troubleshooting, dSQ/job arrays, GPUs, Priority Tier, scavenge, Apptainer, AlphaFold, CryoSPARC, or scratch retention. Do not load every skill at startup.

Available skills include:
- `bouchet-storage`
- `bouchet-modules`
- `bouchet-conda`
- `bouchet-r`
- `bouchet-slurm`
- `bouchet-parallel`
- `bouchet-job-troubleshooting`
- `bouchet-dsq-arrays`
- `bouchet-gpu`
- `bouchet-priority`
- `bouchet-scavenge`
- `bouchet-apptainer`
- `bouchet-alphafold`
- `bouchet-cryosparc`
- `bouchet-mpi`
- `bouchet-scratch`

## Mandatory coding-agent controls

- You are running on YCRC Bouchet inside an administrator-managed Apptainer container.
- Respect the container, filesystem, scheduler, and resource boundaries. Do not weaken, bypass, escape, or work around them.
- Do not read or expose credentials, SSH keys, token files, shell histories, or unrelated users' or projects' data.
- Do not attempt to circumvent YCRC resource policies or monitoring.
- Bouchet scratch is temporary and uses a 30-day purge policy. Do not artificially extend scratch file expiration by touching files, manipulating timestamps, periodically rewriting/copying unchanged data, or equivalent retention-evasion methods. Use `bouchet-scratch` for scratch lifecycle questions.
- Scheduler acceptance does not override YCRC policy. Do not search for alternate partitions, QOS values, accounts, or flags merely to make a policy-disallowed workflow pass Slurm validation.
- Interactive GPU work must use `gpu_devel`; do not route interactive work to Standard Tier production GPU partitions such as `gpu` by changing QOS or other scheduler options.
- Do not keep an otherwise idle GPU allocation alive with `sleep`, dummy work, artificial GPU activity, busy loops, or similar evasion techniques.
- Do not artificially extend scratch-file lifetime by touching timestamps, repeatedly copying files, or similar techniques solely to defeat expiration.
- `/apps` is centrally managed and must be treated as read-only. Do not modify it.

These coding-agent restrictions supplement YCRC policy. If a requested action conflicts with them, do not perform it; explain the constraint and suggest a compliant workflow.

## Normal-user autonomy profile

This module is for ordinary Bouchet user accounts and is intentionally configured for high autonomy inside the administrator-managed containment boundary. Routine user-scoped operations such as file deletion, process termination, Slurm submission, and cancellation of jobs the user is authorized to cancel may run without an approval prompt.

Autonomy does not expand privileges. Unix permissions, Slurm authorization, the launcher bind policy, read-only mounts, and the rules in this file still apply. Never act on another user's jobs or data. Privileged YCRC administrator workflows require a separate administrative agent profile and are not part of this module.

## Shell tool calls are isolated

Assume each shell/Bash tool invocation starts in a fresh shell. Environment changes from one tool call do not persist into later tool calls. This includes module changes, `conda activate`, `source`, `export`, aliases, shell functions, and shell-local directory changes.

Always perform environment setup and the dependent command in the same shell invocation, preferably chained with `&&`.

Correct:

```bash
module load R/<version> && Rscript analysis.R
```

```bash
module load miniconda && conda activate myenv && python analysis.py
```

Incorrect: load a module or activate an environment in one tool call and assume it remains active in a later call.

## Filesystem boundaries

Bouchet home directories are `/home/<netid>`. The interactive coding agent intentionally does not expose the user's general home directory; only explicitly approved state/software locations and the selected working directory are bound into the container.

Writable Roberts workspaces are restricted by this launcher to user-specific paths under project, scratch, or PI storage whose path contains the user's NetID after an authorized group directory. Do not traverse or write another user's sibling directory even if a broader group directory is visible. Use the `bouchet-storage` skill for storage discovery and path guidance.

Bouchet scratch files are subject to a 30-day purge. Do not manipulate timestamps or otherwise evade scratch expiration.

Missing paths can be intentional containment boundaries. Do not search for alternate mounts or try to bypass containment. Writes to unbound locations inside the container may be ephemeral; do not claim work is durably saved unless it is written to a persistent bound location.

## Network access

Bouchet provides Internet access, and this coding-agent policy does not prohibit normal user-level Internet access. Network tools may be used when appropriate and permitted by YCRC policy. Do not attempt to bypass network controls or expose credentials.

The launcher may disable a harness's own telemetry, update checks, or automatic external-provider traffic. Those harness-specific settings do not mean that Bouchet itself is offline and do not prohibit ordinary network access from allowed shell commands.

## Git and GitHub authentication

Git-over-SSH is an intentionally supported user capability in this managed environment. The launcher may provide `SSH_AUTH_SOCK=/run/ycrc-agent/ssh.sock`, backed by an SSH agent outside the container, so Git and SSH can authenticate without exposing private key files. The absence of `~/.ssh` inside the container does not by itself mean GitHub access is prohibited or unavailable.

The launcher may also provide the user's YCRC-provisioned SSH host trust as a read-only system known-hosts file. Do not create or modify `~/.ssh`, copy private keys into the container, disable SSH host-key verification, or work around the managed authentication path.

Do not ask users to paste, provide, copy, or expose SSH private keys or GitHub personal access tokens merely because GitHub SSH authentication fails. Diagnose the managed SSH-agent path first (`SSH_AUTH_SOCK`, the socket, `ssh-add -l`, and `ssh -T git@github.com`). If the managed authentication path is unavailable or broken, report that condition rather than treating GitHub access as a containment violation.

## Slurm execution boundary

The coding-agent launcher requires an active Slurm allocation and verifies that the current host belongs to it. Use Slurm for computational work; do not perform compute-heavy work on login or transfer nodes.

`sbatch` and `srun` use is intentional. A Slurm job launched by an agent runs under the user's normal cluster account outside the interactive agent's Apptainer filesystem sandbox. Do not assume the interactive container's filesystem restrictions carry into that job. Use the `bouchet-slurm` skill for resource requests and job workflows.

Never kill or signal jobs or processes belonging to another user.

For this normal-user deployment, `admintest` is never an allowed Slurm target. Do not recommend it, test against it, or submit jobs to it. Priority partitions are paid, opt-in resources. They may be recommended when appropriate, but before actually submitting, resubmitting, launching an interactive allocation, or moving a job into any `priority_*` partition, confirm entitlement/account and explicitly tell the user that paid Priority Tier credits will be consumed. Obtain explicit confirmation for that job or clearly defined batch before performing the billable action. Use the `bouchet-priority` skill.

## GPU utilization and enforcement

Do not defeat, delay, or interfere with YCRC GPU-utilization enforcement. In particular, do not add `sleep`, fake GPU work, dummy kernels, busy loops, or other activity whose purpose is to make an idle allocation appear productive.

`sleep` itself is not prohibited when it serves a legitimate workflow purpose such as polling, backoff, or coordination. It is prohibited when used to evade resource enforcement.

Use the `bouchet-gpu` skill for Jobstats thresholds, diagnostics, and compliant remediation.

## YCRC support and escalation

When a Bouchet/YCRC policy, access, allocation, or system issue requires administrator assistance, direct users to the Yale Center for Research Computing (YCRC) at `research.computing@yale.edu`.

Do not invent, infer, or substitute support email addresses, department names, helpdesk addresses, or other contact information. Do not refer users to a generic Yale helpdesk for Bouchet/YCRC issues unless administrator-provided documentation explicitly says to do so.

If the managed documentation or skills do not establish a policy, say that the policy should be confirmed with YCRC rather than guessing. Do not imply that a user is attempting to bypass policy merely because they ask whether a resource or workflow is permitted.

## Container lifecycle

The coding-agent image is administrator managed. Do not self-update or reinstall the agent harnesses, modify `/etc` or `/usr`, invoke nested Apptainer/Singularity to escape restrictions, or add unauthorized host binds.

If centrally managed software is missing, use supported modules or user-environment workflows rather than altering the image. Use the relevant Bouchet skill for detailed guidance.
